package model;

public abstract class Bmi {
    private String nama;
    private double beratKg;
    private double tinggiCm;

    public Bmi(String nama, double beratKg, double tinggiCm) {
        this.nama = nama;
        this.beratKg = beratKg;
        this.tinggiCm = tinggiCm;
    }

    public String getNama() {
        return nama;
    }

    public double getBeratKg() {
        return beratKg;
    }

    public double getTinggiCm() {
        return tinggiCm;
    }

    public double getTinggiMeter() {
        return tinggiCm / 100.0;
    }

    public double hitungBmi() {
        if (tinggiCm <= 0) return 0;
        return beratKg / (getTinggiMeter() * getTinggiMeter());
    }

    public String getKategori() {
        double bmi = hitungBmi();
        if (bmi < 18.5) {
            return "Kurang Berat Badan (Underweight)";
        } else if (bmi < 25.0) {
            return "Normal (Ideal)";
        } else if (bmi < 30.0) {
            return "Kelebihan Berat Badan (Overweight)";
        } else {
            return "Obesitas (Obesity)";
        }
    }

    public abstract double hitungBeratIdeal();
}
