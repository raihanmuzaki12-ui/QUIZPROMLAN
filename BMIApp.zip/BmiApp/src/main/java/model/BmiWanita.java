package model;

public class BmiWanita extends Bmi {

    public BmiWanita(String nama, double beratKg, double tinggiCm) {
        super(nama, beratKg, tinggiCm);
    }

    @Override
    public double hitungBeratIdeal() {
        return (getTinggiCm() - 100) - ((getTinggiCm() - 100) * 0.15);
    }
}
