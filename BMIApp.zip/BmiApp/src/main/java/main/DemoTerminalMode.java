package main;

import java.util.Scanner;
import model.Bmi;
import model.BmiPria;
import model.BmiWanita;

public class DemoTerminalMode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== DEMO TERMINAL MODE: KALKULATOR BMI ===");
        System.out.print("Masukkan Nama: ");
        String nama = scanner.nextLine();

        System.out.print("Pilih Jenis Kelamin (1 = Pria, 2 = Wanita): ");
        int jenis = scanner.nextInt();

        System.out.print("Masukkan Berat Badan (kg): ");
        double berat = scanner.nextDouble();

        System.out.print("Masukkan Tinggi Badan (cm): ");
        double tinggi = scanner.nextDouble();

        Bmi bmiObj;
        if (jenis == 1) {
            bmiObj = new BmiPria(nama, berat, tinggi);
        } else {
            bmiObj = new BmiWanita(nama, berat, tinggi);
        }

        System.out.println("\n-------------------------------------------");
        System.out.println("Nama         : " + bmiObj.getNama());
        System.out.printf("Skor BMI     : %.2f\n", bmiObj.hitungBmi());
        System.out.println("Kategori     : " + bmiObj.getKategori());
        System.out.printf("Berat Ideal  : %.1f kg\n", bmiObj.hitungBeratIdeal());
        System.out.println("-------------------------------------------");

        scanner.close();
    }
}
