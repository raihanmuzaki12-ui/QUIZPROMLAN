package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Bmi;
import model.BmiPria;
import model.BmiWanita;

public class BmiController {

    @FXML private TextField txtNama;
    @FXML private TextField txtBerat;
    @FXML private TextField txtTinggi;
    @FXML private RadioButton rbPria;
    @FXML private RadioButton rbWanita;
    @FXML private ToggleGroup genderGroup;

    @FXML private Label lblHasilBmi;
    @FXML private Label lblKategori;
    @FXML private Label lblBeratIdeal;

    @FXML
    private void handleHitung() {
        try {
            String nama = txtNama.getText().trim();
            double berat = Double.parseDouble(txtBerat.getText());
            double tinggi = Double.parseDouble(txtTinggi.getText());

            if (nama.isEmpty()) {
                showAlert("Peringatan", "Nama tidak boleh kosong!");
                return;
            }

            Bmi bmiObj;
            if (rbPria.isSelected()) {
                bmiObj = new BmiPria(nama, berat, tinggi);
            } else {
                bmiObj = new BmiWanita(nama, berat, tinggi);
            }

            lblHasilBmi.setText(String.format("%.2f", bmiObj.hitungBmi()));
            lblKategori.setText(bmiObj.getKategori());
            lblBeratIdeal.setText(String.format("%.1f kg", bmiObj.hitungBeratIdeal()));

        } catch (NumberFormatException e) {
            showAlert("Error Input", "Masukkan angka berat dan tinggi yang valid!");
        }
    }

    @FXML
    private void handleReset() {
        txtNama.clear();
        txtBerat.clear();
        txtTinggi.clear();
        rbPria.setSelected(true);
        lblHasilBmi.setText("-");
        lblKategori.setText("-");
        lblBeratIdeal.setText("-");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
